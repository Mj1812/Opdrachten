-- =============================================
-- Author:		Marco Jacobs
-- Create date: 14-12-2018
-- Description:	gets the answers of a certain question
-- =============================================
CREATE PROCEDURE [dbo].[GetAnswers] 
	-- Add the parameters for the stored procedure here
	@QuestionId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    SELECT [Answer].[Id], [Answer].[AnswerString], [Answer].[Correct]
	FROM [Answer] 
	WHERE [Answer].[QuestionId] = @QuestionId 
    
END
go

