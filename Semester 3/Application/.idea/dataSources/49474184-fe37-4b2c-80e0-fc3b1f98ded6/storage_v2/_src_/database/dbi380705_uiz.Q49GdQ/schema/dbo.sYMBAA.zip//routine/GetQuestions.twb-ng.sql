-- =============================================
-- Author:		Marco Jacobs
-- Create date: 14-12-2018
-- Description:	Gets a list of 5 random question
-- =============================================
CREATE PROCEDURE [dbo].[GetQuestions]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    SELECT TOP 5 [Question].[Id], [Question].[QuestionString]
	FROM [Question]
	ORDER BY NEWID();
    
END
go

