-- =============================================
-- Author:		Marco Jacobs
-- Create date: 05-12-2018
-- Description:	If an account exists then return account else insert account and return that account
-- =============================================
CREATE PROCEDURE [dbo].[RegisterAccount] 
	-- Add the parameters for the stored procedure here
	@Email nvarchar(MAX), 
	@Username nvarchar(MAX),
	@Password nvarchar(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    INSERT INTO [Account] ([Username],[Password], [Email]) OUTPUT INSERTED.[Id], INSERTED.[Username], INSERTED.[Email] VALUES (@Username, @Password, @Email);
END
go

