-- =============================================
-- Author:		Marco Jacobs
-- Create date: 05-12-2018
-- Description:	Returns the email and password of an account
-- =============================================
CREATE PROCEDURE [dbo].[LoginAccount] 
	-- Add the parameters for the stored procedure here
	@Username nvarchar(MAX), 
	@Password nvarchar(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    SELECT [Account].[Id], [Account].[Username] 
	FROM [Account] 
	WHERE [Account].[Username] = @Username 
	AND [Account].[Password] = @Password;
    
END
go

